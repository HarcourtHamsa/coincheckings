<?php

header("Location: https://okexfinance.net/");
?>